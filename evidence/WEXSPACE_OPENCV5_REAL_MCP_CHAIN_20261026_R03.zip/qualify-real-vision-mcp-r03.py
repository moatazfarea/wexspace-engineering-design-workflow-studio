"""Real OpenCV5 -> guarded agent bridge -> official MCP server -> existing quantity engine.
Uses a new private synthetic demo state; never the owner's production database.
"""
import hashlib,json,os,pathlib,socket,subprocess,sys,time,urllib.request,datetime,shutil
base=pathlib.Path('/home/ubuntu/.local/share/wexspace/opencv5-20261026-r02')
app=base/'engine-source'
source=base/'source'
os.umask(0o077)
u='https://raw.githubusercontent.com/moatazfarea/wexspace-engineering-design-workflow-studio/3086377779b5b5405a50b27fb6364df9070b8e03/opencv_candidate/agent_bridge.py'
with urllib.request.urlopen(u,timeout=20) as r:data=r.read(100000)
assert hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()=='a7980291c3d584b5533b408a4bbb97066c67b474'
target=source/'agent_bridge.py'
if target.exists():assert target.read_bytes()==data
else:target.write_bytes(data)
sys.path.insert(0,str(source))
import cv2
from vision import analyze
from agent_bridge import dispatch
assert cv2.__version__=='5.0.0'
run=base/'real-mcp-vision-r03'
run.mkdir(mode=0o700,exist_ok=False)
for port in (4198,4199):
    with socket.socket() as s:s.bind(('127.0.0.1',port))
env=os.environ.copy()
env.update(PORT='4198',MCP_PORT='4199',WEXSPACE_ENGINE_PORT='4198',WEXSPACE_DEMO_DATA=str(run/'backend'))
children=[];logs=[];seq=0;calls=[]
receipt={'record_id':'WEXSPACE_OPENCV5_REAL_MCP_CHAIN_20261026_R03','started_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'evidence_class':'REAL_AWS_OPENCV5_OFFICIAL_MCP_SYNTHETIC_INPUT','instance_id':'i-0cf19ff3becf40838','boot_id':pathlib.Path('/proc/sys/kernel/random/boot_id').read_text().strip(),'source_commit':'3086377779b5b5405a50b27fb6364df9070b8e03','opencv_version':cv2.__version__,'new_cloud_resources':0,'paid_model_calls':0,'public_ports_opened':0,'original_owner_database_accessed':False,'steps':[]}
def start(cmd,name):
    f=(run/(name+'.log')).open('w');logs.append(f)
    p=subprocess.Popen(cmd,cwd=app,env=env,stdout=f,stderr=subprocess.STDOUT);children.append(p);return p
def request(url,body=None):
    req=urllib.request.Request(url,data=None if body is None else json.dumps(body).encode(),headers={'Content-Type':'application/json','Accept':'application/json, text/event-stream'})
    with urllib.request.urlopen(req,timeout=12) as r:
        text=r.read(200000).decode()
        if text.startswith('event:') or text.startswith('data:'):text='\n'.join(t[6:] for t in text.splitlines() if t.startswith('data: '))
        return json.loads(text)
def rpc(method,params=None):
    global seq
    seq+=1
    result=request('http://127.0.0.1:4199/mcp',{'jsonrpc':'2.0','id':seq,'method':method,'params':params or {}})
    if 'error' in result:raise RuntimeError(str(result['error']))
    return result['result']
def tool(name,args=None):
    calls.append(name)
    result=rpc('tools/call',{'name':name,'arguments':args or {}})
    if result.get('isError'):raise RuntimeError(str(result)[:900])
    return result.get('structuredContent') or json.loads(next(v['text'] for v in result['content'] if v['type']=='text'))
try:
    node=start([shutil.which('node'),'server.mjs'],'backend')
    for _ in range(60):
        try:request('http://127.0.0.1:4198/health');break
        except Exception:
            if node.poll() is not None:raise RuntimeError('New isolated backend exited')
            time.sleep(.1)
    else:raise RuntimeError('Backend readiness timeout')
    mcp=start([sys.executable,'mcp_server.py'],'mcp')
    for _ in range(80):
        try:
            init=rpc('initialize',{'protocolVersion':'2026-07-28','capabilities':{},'clientInfo':{'name':'wexspace-opencv5-real-chain','version':'20261026-r03'}})
            break
        except Exception:
            if mcp.poll() is not None:raise RuntimeError('New isolated MCP server exited')
            time.sleep(.1)
    else:raise RuntimeError('MCP readiness timeout')
    discovered=rpc('tools/list')['tools']
    assert {v['name'] for v in discovered}=={'inspect_project','update_room','export_dossier'}
    receipt['steps'].append({'initialize':init,'tools':[v['name'] for v in discovered]})
    before=tool('inspect_project')
    assert before['revision']==0
    assumptions=before['room'].copy()
    ref={'known_metres':2,'pixel_endpoints':[[120,650],[320,650]]}
    perception=analyze(base/'aws_room.png',ref)
    count=len(calls)
    blocked=dispatch(perception,confirmed=False,assumptions=assumptions,calculate=lambda **kwargs: (_ for _ in ()).throw(AssertionError('unconfirmed execution')))
    assert blocked['status']=='NEEDS_HUMAN_CONFIRMATION' and len(calls)==count
    missing=dispatch(analyze(base/'aws_room.png'),confirmed=True,assumptions=assumptions,calculate=lambda **kwargs: (_ for _ in ()).throw(AssertionError('missing scale execution')))
    assert missing['action']=='REQUEST_SCALE' and len(calls)==count
    perspective=dispatch(analyze(base/'aws_perspective.png',ref),confirmed=True,assumptions=assumptions,calculate=lambda **kwargs: (_ for _ in ()).throw(AssertionError('perspective execution')))
    assert perspective['action']=='REQUEST_RECTIFICATION' and len(calls)==count
    receipt['steps'].append({'perception':perception,'review_boundary':'Explicit synthetic fixture confirmation only; no physical room sign-off','unconfirmed':blocked,'missing_scale':missing,'perspective':perspective,'blocked_cases_tool_calls':0})
    op='aws-opencv5-real-chain-20261026-r03'
    def actual_calculation(*,room):
        return tool('update_room',{'patch':room,'expected_revision':before['revision'],'operation_id':op})
    result=dispatch(perception,confirmed=True,assumptions=assumptions,calculate=actual_calculation)
    assert result['status']=='CALCULATION_TOOL_RETURNED'
    quantity=result['provider_result']
    assert quantity['revision']==1 and quantity['room']['length']==6.04 and quantity['room']['width']==4.04
    assert quantity['quantities']['floor_m2']==24.4016 and quantity['quantities']['paint_litres']==12.276 and quantity['quantities']['tile_count']==75
    independent=request('http://127.0.0.1:4198/api/action',{'action':'inspect'})['result']
    assert independent['revision']==1 and independent['room']==quantity['room']
    assert not independent['room']['includeCeiling']
    receipt['steps'].append({'bridge_result':result,'independent_backend_readback':independent})
    replay=dispatch(perception,confirmed=True,assumptions=assumptions,calculate=actual_calculation)
    assert replay['provider_result']['cached'] is True and replay['provider_result']['revision']==1
    exported=tool('export_dossier')
    assert '24.4016' in exported['csv'] and '12.276' in exported['csv']
    (run/'quantity-schedule.csv').write_text(exported['csv'])
    after=tool('inspect_project')
    assert after['revision']==1 and len(after['audit'])==1
    receipt['steps'].append({'duplicate_effect_prevented':True,'replay_cached':True,'final_revision':1,'audit_count':1,'export_sha256':hashlib.sha256(exported['csv'].encode()).hexdigest(),'actual_tool_calls':calls})
    receipt['status']='PASS_SCOPED_REAL_AWS_VISION_TO_MCP_ENGINE'
    receipt['remaining']=['physical-image calibration and human review','hosted UI vision endpoint','native ChatGPT invocation of image tool','dynamic product video','contest submission','full Stage 1 commercial qualification']
except Exception as e:
    receipt['status']='FAIL';receipt['error']={'type':type(e).__name__,'message':str(e)[:1200]}
finally:
    # Only the two child processes created by this isolated qualification are stopped.
    for p in reversed(children):
        if p.poll() is None:p.terminate()
    for p in children:
        try:p.wait(timeout=8)
        except subprocess.TimeoutExpired:receipt.setdefault('cleanup_pending',[]).append(p.pid)
    for f in logs:f.close()
    receipt['finished_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat()
    out=run/'receipt.json';out.write_text(json.dumps(receipt,indent=2))
    print(json.dumps({'status':receipt['status'],'receipt':str(out),'sha256':hashlib.sha256(out.read_bytes()).hexdigest(),'steps':len(receipt['steps']),'error':receipt.get('error')}))
    if receipt['status']=='FAIL':
        for n in ('backend.log','mcp.log'):print(n,(run/n).read_text()[-1800:])
sys.exit(0 if receipt['status'].startswith('PASS') else 1)
